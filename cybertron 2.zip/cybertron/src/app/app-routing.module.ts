import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { DatasComponent } from './pages/categories/datas/datas.component';

const routes: Routes = [
   //{ path: 'next', loadChildren: './pages/categories/categories.module.ts#CategoriesModule'},
   //{ path: 'new', loadChildren: './pages/categories/categories.module.ts#CategoriesModule'}


   {path: 'next' , component: DatasComponent},
   {path: 'id:', component: AppComponent},
   {path: 'home', component: AppComponent},
   
   
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
