import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CategoriesRoutingModule } from './categories-routing.module';

import { DatasComponent } from './datas/datas.component';
import { NgxMaskModule } from 'ngx-mask';


@NgModule({
  declarations: [
    DatasComponent 
  ],
  imports: [
    CommonModule,
    CategoriesRoutingModule,
    NgxMaskModule.forChild()
  ]
})
export class CategoriesModule { }
