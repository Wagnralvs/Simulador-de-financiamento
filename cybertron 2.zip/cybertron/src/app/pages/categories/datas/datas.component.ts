import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-dadas',
  templateUrl: './datas.component.html',
  styleUrls: ['./datas.component.css']
})
export class DatasComponent implements OnInit {

  //text- formulario

  formulario: FormGroup = new FormGroup({
    Nome: new FormControl(null),
    email: new FormControl(null),
    subject: new FormControl(null),
    message: new FormControl(null),
    })  //


  constructor() { }

  ngOnInit(): void {
    
  }

}
